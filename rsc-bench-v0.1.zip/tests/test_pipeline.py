import json
from pathlib import Path
from rscbench.io import read_jsonl
from rscbench.model_client import MockModelClient
from rscbench.runner import run_one
from rscbench.schemas import CCDG, Case, GroundTruth

ROOT = Path(__file__).resolve().parents[1]

def test_end_to_end_mock_pipeline():
    case = read_jsonl(ROOT/"data/pilot/cases.jsonl", Case)[0]
    truth = read_jsonl(ROOT/"data/pilot/ground_truth.jsonl", GroundTruth)[0]
    ccdg = read_jsonl(ROOT/"data/pilot/ccdg.jsonl", CCDG)[0]
    result = run_one(root=ROOT, case=case, truth=truth, ccdg=ccdg,
                     condition="ccdg", replicate=1, client=MockModelClient())
    assert result["case_id"] == "RSC-PILOT-001"
    assert result["condition"] == "ccdg"
    assert result["match_result"]["primary_accuracy"] == 1
    json.dumps(result)
