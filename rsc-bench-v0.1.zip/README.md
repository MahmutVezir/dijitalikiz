# RSC-Bench

**LLM Tabanlı Çapraz-Bileşen Hata Teşhisinde Yapılandırılmış Bağımlılık Temsilinin Etkisinin Deneysel İncelenmesi**

RSC-Bench (Cross-Component Dependency Graph) deney altyapısı.

## Bilimsel kapsam

Birincil karşılaştırma:
- Standard Context
- CCDG Context

`I_base` iki koşulda aynıdır. Birincil sonuç, deterministik ground-truth eşleşmeli kök neden teşhis doğruluğudur.

v0.1 yalnızca pilot altyapısıdır. Ana veri seti ve ana deney bu pakete dahil değildir.

## Kurulum

Python 3.12 + uv:

```bash
uv sync
uv run pytest
```

Gerçek model çağrısı için `.env` içine API anahtarı eklenir.

## Deney sırası

1. Protocol v1.0
2. Pilot
3. Pilot teknik doğrulama
4. Monte Carlo güç analizi
5. Ana veri seti kilidi
6. Kör ana deney
7. Otomatik JSON matching
8. GLMM analizi
9. Raporlama

Bu sıra sonuçlara göre değiştirilmeyecektir.
