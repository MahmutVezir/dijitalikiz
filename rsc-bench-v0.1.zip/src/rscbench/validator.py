from __future__ import annotations
from .schemas import CCDG, Case, GroundTruth

def validate_case_links(case: Case, truth: GroundTruth, ccdg: CCDG) -> None:
    if case.case_id != truth.case_id or case.case_id != ccdg.case_id:
        raise ValueError("Case, ground truth and CCDG case_id values must match.")
    if not case.contamination.is_pilot:
        raise ValueError("Pilot pipeline requires is_pilot=true.")
    if not case.contamination.excluded_from_main_dataset:
        raise ValueError("Pilot case must be excluded from the main dataset.")
    node_ids = {node.id for node in ccdg.nodes}
    for edge in ccdg.edges:
        if edge.source not in node_ids or edge.target not in node_ids:
            raise ValueError("CCDG edge references an unknown node.")
