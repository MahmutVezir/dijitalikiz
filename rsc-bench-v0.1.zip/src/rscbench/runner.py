from __future__ import annotations
from pathlib import Path
import json
from .hashing import sha256_text
from .freeze import verify_frozen
from .matcher import deterministic_match
from .model_client import ModelClient
from .prompts import PromptBuilder
from .schemas import CCDG, Case, GroundTruth, ModelOutput
from .validator import validate_case_links

def run_one(*, root: Path, case: Case, truth: GroundTruth, ccdg: CCDG,
            condition: str, replicate: int, client: ModelClient) -> dict:
    validate_case_links(case, truth, ccdg)
    verify_frozen(root)
    builder = PromptBuilder(root)
    system, user = builder.render(condition, case, ccdg if condition == "ccdg" else None)
    response = client.generate(system, user)
    parsed = ModelOutput.model_validate(json.loads(response.raw_text))
    match = deterministic_match(parsed, truth)
    return {
        "run_id": f"{case.case_id}-{condition.upper()}-R{replicate}",
        "experiment_id": "PILOT-001",
        "case_id": case.case_id,
        "condition": condition,
        "replicate": replicate,
        "provider": response.provider,
        "model_id": response.model_id,
        "system_prompt_hash": sha256_text(system),
        "user_prompt_hash": sha256_text(user),
        "input_hash": sha256_text(user),
        "raw_response": response.raw_text,
        "parsed_output": parsed.model_dump(),
        "match_result": match.model_dump(),
    }
