from __future__ import annotations
import json
from pathlib import Path
from typing import TypeVar
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)

def read_jsonl(path: Path, model: type[T]) -> list[T]:
    records: list[T] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                records.append(model.model_validate(json.loads(line)))
    return records

def append_jsonl(path: Path, value: BaseModel) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(value.model_dump_json() + "\n")
