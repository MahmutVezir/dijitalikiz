from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class ModelResponse:
    raw_text: str
    provider: str
    model_id: str

class ModelClient:
    def generate(self, system_prompt: str, user_prompt: str) -> ModelResponse:
        raise NotImplementedError

class MockModelClient(ModelClient):
    def generate(self, system_prompt: str, user_prompt: str) -> ModelResponse:
        return ModelResponse(
            raw_text='{"diagnosed_component":"RLS","root_cause_class":"policy_condition_mismatch","affected_entity":"profiles","explanation":"mock"}',
            provider="mock",
            model_id="mock-v0",
        )
