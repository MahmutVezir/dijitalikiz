from pathlib import Path
from rscbench.io import read_jsonl
from rscbench.schemas import CCDG, Case, GroundTruth
from rscbench.validator import validate_case_links

ROOT = Path(__file__).resolve().parents[1]
cases = read_jsonl(ROOT/"data/pilot/cases.jsonl", Case)
truths = {x.case_id:x for x in read_jsonl(ROOT/"data/pilot/ground_truth.jsonl", GroundTruth)}
graphs = {x.case_id:x for x in read_jsonl(ROOT/"data/pilot/ccdg.jsonl", CCDG)}
for case in cases:
    validate_case_links(case, truths[case.case_id], graphs[case.case_id])
print(f"Validated {len(cases)} pilot case(s).")
