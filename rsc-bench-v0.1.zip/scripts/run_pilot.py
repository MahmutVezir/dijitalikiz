from pathlib import Path
import json
from rscbench.io import read_jsonl
from rscbench.model_client import MockModelClient
from rscbench.runner import run_one
from rscbench.schemas import CCDG, Case, GroundTruth

ROOT = Path(__file__).resolve().parents[1]
cases = read_jsonl(ROOT/"data/pilot/cases.jsonl", Case)
truths = {x.case_id:x for x in read_jsonl(ROOT/"data/pilot/ground_truth.jsonl", GroundTruth)}
graphs = {x.case_id:x for x in read_jsonl(ROOT/"data/pilot/ccdg.jsonl", CCDG)}
out = ROOT/"outputs/pilot_mock.jsonl"
out.parent.mkdir(exist_ok=True)
with out.open("w", encoding="utf-8") as handle:
    for case in cases:
        for replicate in range(1, 6):
            for condition in ("standard","ccdg"):
                record = run_one(root=ROOT, case=case, truth=truths[case.case_id],
                                 ccdg=graphs[case.case_id], condition=condition,
                                 replicate=replicate, client=MockModelClient())
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
print(f"Wrote mock pilot output to {out}")
