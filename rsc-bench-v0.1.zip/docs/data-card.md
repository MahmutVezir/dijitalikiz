# RSC-Bench data card

Intended use: experimental study of representation format in cross-component software-error diagnosis.

Planned public sources include GitHub Issues/PRs, Stack Overflow solutions, Supabase/public technical sources, and other independently verifiable technical records.

Do not retain secrets, credentials, private content, or unnecessary personal information.

Pilot cases are permanently excluded from the main benchmark.

The project does not claim that model training-data overlap can be reduced to zero.
