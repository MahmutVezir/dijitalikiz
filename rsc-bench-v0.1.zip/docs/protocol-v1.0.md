# Protocol v1.0 — Working Skeleton

## Research question

Does presenting the same underlying software-error information to a fixed LLM as a structured Cross-Component Dependency Graph (CCDG), rather than standard context, change root-cause diagnosis accuracy?

## Independent variable

Representation format: `standard` or `ccdg`.

## Primary dependent variable

Binary ground-truth-matched diagnosis accuracy: 1 correct, 0 incorrect.

## Replication

Five repeated model calls per case are the current pilot replication factor. Repeats are not independent cases.

## Model

A single fixed model/checkpoint is used within the primary experiment. Provider, exact model/checkpoint/snapshot ID, API/version metadata, generation settings, prompt hashes and other available provenance are recorded.

## Evaluation

The model returns structured JSON. Ground truth is structured. Primary matching is deterministic and pre-specified. LLM-as-a-judge is not the primary metric.

## Contamination

Pilot cases are excluded from the main benchmark. No claim of zero training-data overlap is made.

## Freeze

Prompts are canonicalized, hashed, and frozen before the main experiment. Semantic prompt changes after freeze are prohibited; technical bug fixes are separately recorded.

## Analysis

Pilot results inform a Monte Carlo power analysis. The final statistical model must be specified before the main experiment and must not be selected after inspecting the main outcome.

## Status

Implementation scaffold only; this document is not itself the final approved/frozen protocol.
