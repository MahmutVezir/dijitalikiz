# Reproducibility checklist

- Python version pinned
- dependency lockfile committed
- model/provider/checkpoint recorded
- generation parameters recorded
- prompt hashes recorded
- input hash recorded
- raw response retained
- parsed response retained
- schema validation result retained
- deterministic matching result retained
- experiment and replicate identifiers retained
- timestamps retained
- pilot/main separation enforced
- no secrets committed
