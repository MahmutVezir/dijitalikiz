# Pilot protocol

The pilot validates mechanics, not the research conclusion.

Checks:
- case/ground-truth/CCDG validation
- identical I_base across conditions
- prompt canonicalization and hashing
- frozen-prompt enforcement
- JSON parsing and schema validation
- deterministic matching
- raw response preservation
- provenance preservation
- error handling
- pilot exclusion from the future main benchmark
