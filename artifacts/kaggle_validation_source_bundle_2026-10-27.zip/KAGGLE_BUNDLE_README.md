# Kaggle doğrulama kaynak paketi

- Kaynak depo: `MahmutVezir/dijitalikiz`
- Sabit kaynak commit'i: `e153e12f58b3148dfc0d3e525233aeaf9ba3edd6`
- Amaç: Kaggle'da model çalıştırmadan kod birim/sözleşme testlerini ve salt-okunur hazır olma kontrolünü çalıştırmak.
- Kaynak dosyası sayısı: 29 (ek olarak bu README ve BUNDLE_MANIFEST.json bulunur).

## Kullanım

1. ZIP'i Kaggle'da bir Dataset olarak yükleyin.
2. Notebook'a bu Dataset'i Add Input ile ekleyin.
3. ZIP içeriğini `/kaggle/working/dijitalikiz-validation-source` yoluna açın. `scripts/`, `tests/`, `research_candidates/` ve `.github/` klasörleri proje kökünün altındadır.
4. Kaynak paketi salt-okunur kabul edin; testler çalışma kopyasında yürütülmelidir.

## Güvenlik ve bilimsel sınırlar

- Model ağırlıkları yüklenmez; model çıkarımı yapılmaz.
- Upstream projelerin buggy/fixed hedef testleri çalıştırılmaz.
- Vaka sicili veya manifest otomatik olarak değiştirilmez.
- `inference_allowed=false`, açık veri kapısı ve sıfır kabul edilmiş vaka sayısı mevcut durumla uyumludur. Bu paket deney izni değildir.
- Test hataları çıktığında günlükleri incelemeden kod değiştirmeyin.

## Dosya bütünlüğü

`BUNDLE_MANIFEST.json` her kaynak dosyasının Git blob SHA-1 kimliğini ve bayt uzunluğunu listeler. Git blob SHA-1, notebook'un hesapladığı dosya SHA-256 özetiyle aynı şey değildir.
