# Kaggle doğrulama kaynak paketi v2

- Kaynak depo: `MahmutVezir/dijitalikiz`
- Sabit kaynak commit'i: `99663c2874424feb9cec1d965432030f5cdb3ef8`
- Kaynak dosya sayısı: 31
- Amaç: Kaggle'da model çalıştırmadan kod birim/sözleşme testlerini ve salt-okunur hazır olma kontrolünü yürütmek.

## v1'den gelen düzeltmeler

- Tarihsel araştırmacı maruziyet kayıtları eklendi: `EXPOSURE_EXCLUSION_ADDENDUM_2026-10-22.json` ve `EXPOSURE_EXCLUSION_LOG_2026-10-21.json`.
- `test_kaggle_stage3_prompt_contract.py` beklentisi düzeltildi. Üretim prompt'u değiştirilmedi; test şimdi gerçek satır sonunu doğruluyor.
- Dokuz test dosyası ve gerekli Python kaynakları aynı arşivde.

## Kaggle'da kullanım

1. ZIP'i Kaggle'da Dataset olarak yükleyin.
2. Notebook'a **Add Input** ile ekleyin.
3. v5 no-inference notebook'unu çalıştırın; ZIP içeriği `/kaggle/working/` altında açılır.
4. Test raporu ve günlükleri incelenene kadar hiçbir modeli çalıştırmayın.

## Bilimsel güvenlik sınırları

- Model yükleme ve çıkarım yapılmaz.
- Upstream buggy/fixed hedef testleri yapılmaz.
- Vaka sicili veya deney manifesti değiştirilmez.
- Dışlama kayıtları kalıcıdır; paket bunları gevşetmez.
- Paket testleri geçse bile deney izni değildir. Ön kayıt, bağımsız vaka doğrulaması, değerlendirici kalibrasyonu, runtime ve hash kapıları ayrıca tamamlanmalıdır.

`BUNDLE_MANIFEST.json` her kaynak dosyası için Git blob SHA-1 ve bayt uzunluğu içerir. Notebook bu kimlikleri tekrar hesaplayarak içerik bütünlüğünü kontrol eder.
