### pyfar #721 exact fail-to-pass reproduction
- Buggy base: 648dda4c60c5a6f74acf335f7808c590c9d23929
- Fixed revision: a4d72d380bb8ddb0950d334eb1b0793ee6d86e0e
- Dataset FAIL_TO_PASS selectors are extracted from the exact pinned Parquet row
- No model loading, inference, or training
