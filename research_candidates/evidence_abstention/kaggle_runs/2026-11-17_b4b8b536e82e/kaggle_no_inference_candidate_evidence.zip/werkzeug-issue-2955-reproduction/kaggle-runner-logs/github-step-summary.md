### Werkzeug #2955 exact fail-to-pass reproduction
- Buggy base: 40319f91dbbae0a780526eab037a009b1a7e4d36
- Fixed revision: 1688968101c3341136bd8420ac7b77b6286c7409
- Dataset FAIL_TO_PASS selectors are extracted from the exact pinned Parquet row
- No model loading, inference, or training
