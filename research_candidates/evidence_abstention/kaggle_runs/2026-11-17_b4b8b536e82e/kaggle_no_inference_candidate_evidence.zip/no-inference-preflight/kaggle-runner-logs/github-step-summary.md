Packet audit-test exit code: 0
Operational packet tests exit code: 0
v0.2 exploratory contract test exit code: 0
SWE-rebench V2 v0.2 exploratory readiness report command exit code: 0
