### Moto #8269 ECR multi-tag reproducer
- Buggy base: bf49e22f41be7444dc20e05dfa5dd13f25672eba
- Fixed revision: d46db48b4911d84235ef783ddab41b73882530f7
- No AWS account or external service used
- No model loading, inference, or training
