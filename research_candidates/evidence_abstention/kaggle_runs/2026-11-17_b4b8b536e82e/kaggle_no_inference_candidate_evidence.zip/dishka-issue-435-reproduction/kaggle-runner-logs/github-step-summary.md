### Dishka #435 exact fail-to-pass reproduction
- Buggy base: 8718d5af93f9e48bc2506c64827663fdccc5ad89
- Fixed revision: b1eae11734e64551d7b101195f27cb6870e1c364
- Same selector: test_issue_435_override_lower_scope
- Python: 3.11.9; no pip dependencies installed; stdlib unittest only
- Issue reproducer: base fails with AssertionError 1 != 42; fixed revision passes
- Dataset FAIL_TO_PASS: all 8 selectors fail on base after test-patch application and pass on fixed revision
