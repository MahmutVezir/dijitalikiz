### Robocop #1371 exact fail-to-pass reproduction
- Buggy base: 271e73253a70710cc80374128efa9eabb549b5f2
- Fixed revision: ceb6824fb4d80442937497a740edf60a5b6382e0
- Dataset FAIL_TO_PASS selectors are extracted from the exact pinned Parquet row
- No model loading, inference, or training
