### EODAG #1530 minimal YAML duplicate-key reproducer
- Buggy base: b7cc06e19025e5bbf14e28a0975f1749e21e9be3
- Fixed revision: 312966a46513a082333d46cd7212bdce36aaf769
- Minimal runtime: Python 3.11.9 + PyYAML 6.0.2
- Dataset FAIL_TO_PASS selectors were captured but not executed in this minimal environment
- No model loading, inference, or training
