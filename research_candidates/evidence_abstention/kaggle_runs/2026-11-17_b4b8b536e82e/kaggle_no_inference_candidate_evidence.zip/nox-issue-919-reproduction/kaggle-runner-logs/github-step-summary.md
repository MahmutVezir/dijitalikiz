### Nox #919 exact fail-to-pass reproduction
- Buggy base: 97e0fad6a4036d610591a52e9ad0cfbe74a31af3
- Fixed revision: 5c4000550325fd1ad036716d9e600ef7411bed3d
- Independent reproducer: PATH-visible uv shim exits 127; base must report HAS_UV=True and fixed revision HAS_UV=False
- Dataset FAIL_TO_PASS selectors are extracted from the exact pinned Parquet row
- No model loading, inference, or training
