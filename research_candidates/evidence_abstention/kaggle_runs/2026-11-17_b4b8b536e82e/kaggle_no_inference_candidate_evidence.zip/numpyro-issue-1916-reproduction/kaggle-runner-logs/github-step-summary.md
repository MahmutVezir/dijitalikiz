### NumPyro #1916 exact fail-to-pass reproduction
- Buggy base: 07e4c9bc4524cc0a741ba8f8ad41339d34a0288d
- Fixed revision: 5692d2da335945b756aeae02e3720b9b7f3efef2
- Dataset FAIL_TO_PASS selectors are extracted from the exact pinned Parquet row
- CPU-only JAX; no model loading, inference, or training
